import os
import subprocess
import torch
import librosa
import fasttext
import srt
from datetime import timedelta
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor, MarianMTModel, MarianTokenizer

# ==========================================
# Module 1: Audio Extraction
# ==========================================
class AudioExtractor:
    """Extracts and normalizes audio using FFmpeg."""
    
    @staticmethod
    def extract_audio(video_path: str, output_wav: str) -> str:
        """Extracts audio to 16kHz mono WAV format."""
        command = [
            'ffmpeg', '-y', '-i', video_path,
            '-ac', '1',          # mono channel
            '-ar', '16000',      # 16kHz sample rate
            '-sample_fmt', 's16', # 16-bit PCM
            output_wav
        ]
        subprocess.run(command, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return output_wav

# ==========================================
# Module 2 & 3: Speech Segmentation & ASR
# ==========================================
class SpeechRecognizer:
    """Handles speech recognition using Wav2Vec 2.0."""
    
    def __init__(self, model_id="facebook/wav2vec2-large-960h-lv60-self"):
        self.processor = Wav2Vec2Processor.from_pretrained(model_id)
        self.model = Wav2Vec2ForCTC.from_pretrained(model_id)
        
    def transcribe_audio(self, audio_path: str):
        """Loads audio, simulates segmentation, and transcribes."""
        speech, rate = librosa.load(audio_path, sr=16000)
        
        # Simulating chunking for memory management (30-second chunks)
        chunk_length_s = 30 
        chunk_length = rate * chunk_length_s
        transcripts = []
        
        for i in range(0, len(speech), chunk_length):
            chunk = speech[i:i+chunk_length]
            start_time = i / rate
            end_time = (i + len(chunk)) / rate
            
            input_values = self.processor(chunk, return_tensors="pt", sampling_rate=rate).input_values
            logits = self.model(input_values).logits
            predicted_ids = torch.argmax(logits, dim=-1)
            transcription = self.processor.batch_decode(predicted_ids)[0]
            
            if transcription.strip():
                transcripts.append({
                    "text": transcription.capitalize(),
                    "start": start_time,
                    "end": end_time
                })
                
        return transcripts

# ==========================================
# Module 4: Language Identification
# ==========================================
class LanguageIdentifier:
    """Identifies source language using FastText LID."""
    
    def __init__(self, model_path="lid.176.bin"):
        try:
            self.model = fasttext.load_model(model_path)
        except Exception as e:
            print(f"Warning: Could not load FastText model. Ensure {model_path} is downloaded. Defaulting to English.")
            self.model = None

    def identify(self, text: str) -> str:
        if not self.model: return "en"
        predictions = self.model.predict(text, k=1)
        return predictions[0][0].replace("__label__", "")

# ==========================================
# Module 5: Neural Machine Translation (Polymorphic)
# ==========================================
class Translator:
    def translate(self, text: str) -> str:
        raise NotImplementedError("Subclasses must implement translate()")

class MarianTranslator(Translator):
    def __init__(self, source_lang: str, target_lang: str):
        model_name = f"Helsinki-NLP/opus-mt-{source_lang}-{target_lang}"
        self.tokenizer = MarianTokenizer.from_pretrained(model_name)
        self.model = MarianMTModel.from_pretrained(model_name)
        
    def translate(self, text: str) -> str:
        translated = self.model.generate(**self.tokenizer(text, return_tensors="pt", padding=True))
        return self.tokenizer.decode(translated[0], skip_special_tokens=True)

# ==========================================
# Module 6: Subtitle Generation
# ==========================================
class SubtitleGenerator:
    """Orchestrates the pipeline and formats output to SRT."""
    
    def __init__(self):
        self.extractor = AudioExtractor()
        self.asr = SpeechRecognizer()
        self.lid = LanguageIdentifier()
        self.translators = {} 
        
    def generate_srt(self, video_path: str, target_lang="fr", output_srt="output.srt"):
        print("1. Extracting audio...")
        temp_wav = "temp_audio.wav"
        self.extractor.extract_audio(video_path, temp_wav)
        
        print("2. Transcribing audio (ASR)...")
        segments = self.asr.transcribe_audio(temp_wav)
        
        if not segments:
            print("No speech detected.")
            return
            
        print("3. Identifying language...")
        source_lang = self.lid.identify(" ".join([s['text'] for s in segments[:3]]))
        print(f"Detected Source Language: {source_lang}")
        
        print(f"4. Translating to {target_lang}...")
        if f"{source_lang}-{target_lang}" not in self.translators:
            self.translators[f"{source_lang}-{target_lang}"] = MarianTranslator(source_lang, target_lang)
            
        translator = self.translators[f"{source_lang}-{target_lang}"]
        
        srt_segments = []
        for i, seg in enumerate(segments, start=1):
            translated_text = translator.translate(seg['text'])
            
            srt_segments.append(
                srt.Subtitle(
                    index=i,
                    start=timedelta(seconds=seg['start']),
                    end=timedelta(seconds=seg['end']),
                    content=translated_text
                )
            )
            
        print("5. Generating SRT file...")
        with open(output_srt, "w", encoding="utf-8") as f:
            f.write(srt.compose(srt_segments))
            
        if os.path.exists(temp_wav):
            os.remove(temp_wav)
            
        print(f"Done! Subtitles saved to {output_srt}")
