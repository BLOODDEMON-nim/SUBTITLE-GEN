# Multilingual AI Subtitle Generator

## Prerequisites
1. Install [FFmpeg](https://ffmpeg.org/download.html) and add it to your system PATH.
2. Download the FastText model `lid.176.bin` from [fasttext.cc](https://fasttext.cc/docs/en/language-identification.html) and place it in this folder.

## Setup
1. Open terminal in this folder.
2. Install dependencies: `pip install -r requirements.txt`

## Running Offline
1. Start the backend server: `uvicorn api:app --reload`
2. Open `index.html` in your web browser.
3. Upload your video and generate subtitles!
