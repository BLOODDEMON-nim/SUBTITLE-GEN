from fastapi import FastAPI, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import shutil
import os
import uuid
from subtitle_generator import SubtitleGenerator

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

generator = SubtitleGenerator()

@app.post("/api/generate")
async def generate_subtitles(video: UploadFile = File(...), target_lang: str = Form(...)):
    temp_video_path = f"temp_{uuid.uuid4().hex}_{video.filename}"
    output_srt_path = f"output_{uuid.uuid4().hex}.srt"
    
    try:
        with open(temp_video_path, "wb") as buffer:
            shutil.copyfileobj(video.file, buffer)
            
        print(f"Received {video.filename}, generating {target_lang} subtitles...")
        
        generator.generate_srt(
            video_path=temp_video_path,
            target_lang=target_lang,
            output_srt=output_srt_path
        )
        
        return FileResponse(
            path=output_srt_path, 
            filename=f"{video.filename.split('.')[0]}_{target_lang}.srt",
            media_type='text/plain'
        )
        
    except Exception as e:
        return {"error": str(e)}
        
    finally:
        if os.path.exists(temp_video_path):
            os.remove(temp_video_path)
